# ProdigyInfotech_DS_Task2


This is Task 2 of Data Science Internship at Prodigy Infotech.
